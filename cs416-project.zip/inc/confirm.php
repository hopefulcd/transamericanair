	<tr>
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:100%" cellpadding="5">
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Departure Flight:</span></td></tr>
				<tr class="selectlimit" colspan="100" style="height:25px;">
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Class</td>
					<td colspan="3">Price</td>
				</tr>
				
				<?php echo $dflight; ?>
				
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Return Flight:</span></td></tr>
				<tr class="selectlimit" colspan="100" style="height:25px;">
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Class</td>
					<td colspan="3">Price</td>
				</tr>
				
				<?php echo $rflight; ?>
				
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Reservation Summary:</span></td></tr>
				<tr class="selectlimit" style="height:25px;">
					<td>First Name</td>
					<td>Last Name</td>
					<td>Email</td>
					<td>Shipping Address</td>
					<td>Ticket Quantity</td>
					<td>Discount</td>
					<td>Total</td>
				</tr>
				
				<?php echo $orderSummary; ?>
				
				<tr style="height:25px;">
					<td class="searchlimit" colspan="100">
						<input type="submit" title="Continue To Submit Your Reservation" value="Submit Your Reservation" />
						<input type="hidden" name="dflight" value="<?php echo $in_dflight; ?>" />
						<input type="hidden" name="rflight" value="<?php echo $in_rflight; ?>" />
						<input type="hidden" name="quantity" value="<?php echo $in_quantity; ?>" />
						<input type="hidden" name="cardnum" value="<?php echo $in_cardnum; ?>" />
						<input type="hidden" name="cardmonth" value="<?php echo $in_cardmonth; ?>" />
						<input type="hidden" name="cardyear" value="<?php echo $in_cardyear; ?>" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
