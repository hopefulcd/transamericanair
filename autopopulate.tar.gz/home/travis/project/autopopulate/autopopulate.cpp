// autopopulate creates data to fill the database for CS ARS

#include "customer.h"        // Customer Struct and related functions
#include <ctime>
#include <fstream>


#define COACH_SEATS 40
#define FIRST_CLASS_SEATS 10
#define INITAL_DAYS 90
using namespace std;
void doFlightInfo(int flightNum, int day, int origin, int destination, ostream &out);
tm dayToDate(int day);
char * generateOrderNumber();
char * passport();
char * cardNumber();


int main(void)
{
  cout << "main" << endl;

  struct Customer customer;
  // create random customer list

  cout << "generate customer list" << endl;

  // Create .SQL File
  cout << "creating sql file" << endl;
  ofstream sql;
  sql.open("autopopulate.sql", ios::trunc);
  // write to .SQL for insertion into database
  cout << "writing initial header" << endl;
  
  int j = 500;
  sql << "INSERT INTO `Customer` (`cfirstname`, `cmiddlename`, "
      << "`clastname`, `email`, `address`, `city`, `state`, `zip`, "
      << "`phone`, `passport`, `dob`, `password`) VALUES \n";
  cout << "writing customers" << endl;
  sql.close();
  for (int i = 0; i < MAX_CUSTOMER; i++)
  // i is the counter for customers,
  // j is the counter for rows in the sql statement
  // max rows per insert is 1000, but we are going to do this for every 
  // 500 rows
  {
    sql.open("autopopulate.sql", ios::app);

    if (j == 0 ) 
    { 
      j = 500;
      sql << ";\n\n"; // two backspaces to remove the comma
      sql << "INSERT INTO `Customer` (`cfirstname`, `cmiddlename`, "
          << "`clastname`, `email`, `address`, `city`, `state`, `zip`, "
          << "`phone`, `passport`, `dob`, `password`) VALUES \n";
    } else if( i != MAX_CUSTOMER && i !=0)
      sql << ",\n";
    customer = generateCustomer(customer);

    sql << "(\'" << customer.firstName << "\', " 
        << "\'" << customer.middleName << "\', "
        << "\'" << customer.lastName << "\', "
        << "\'" << customer.email << "\', "
        << "\'" << customer.address << "\', "
        << "\'" << customer.city << "\', "
        << "\'" << customer.state << "\', "
        << "\'" << customer.zip << "\', "
        << "\'" << customer.phone << "\', "
        << "\'" << customer.password << "\', "
        << "\'" << customer.DOB.tm_year + 1900 << ":"
        << customer.DOB.tm_mon << ":"
        << customer.DOB.tm_mday << "\')";
    sql.close();
    j--;
  }
  sql << ";\n\n";
  cout << "Cities" << endl;


  // add Cities to SQL

  sql << "INSERT INTO `City` (`title`, `state`) VALUES \n";
  for (int i = 0; i < TOT_CITIES; i++)
  {
    sql << "(\'" << cityList[i].name << "\', "
        << "\'" << cityList[i].state << "\'),\n";
  }
  sql << "\b\b;\n\n"; // two backspaces to remove comma
  
  cout << "Flight Numbers";
  // create list of flight numbers
  // flightID = flighNum + year + juliandate
  int flightNum = 0;
  for (int i = 0; i < TOT_CITIES; i++) // each departure
  {
    for (int j = 0; j < TOT_CITIES; j++) // each destination
    {
      if( i!= j)
      {
        for (int day = 0; day < INITAL_DAYS; day++) // do for the first 90 days
        {
          doFlightInfo(flightNum, day, i, j, sql);
        }
      }
    }
  }
  // purchase tickets for each flight

  sql.close();
}

void doFlightInfo(int flightNum, int day, int origin, int destination, ostream &out)
{
  char * flightID;
  sprintf(flightID, "%i2013%i", flightNum, day); // print flightID
  tm flightDate = dayToDate(day); // get flight date info
  // figure out how many coach passangers
  int coachLeft = rand() % (COACH_SEATS + 1 ); // + 1 to allow 0-50 seats
  // figure out how many first class passangers  
  int firstClassLeft = rand() % (FIRST_CLASS_SEATS + 1); // +1 to allow 0-10 seats
  out << "INSERT INTO `Flight` (`fid`, `fnumber`, `fdate`, "
      << "`fDepartTime`, `fArivalTime`, `cAvailable`, "
      << "`fcAvailable`, `orig`, `dest`) VALUE \n"; // sql header  for flight
  out << "(\'" << flightID << "\', \'" << flightNum << "\', "
      << "\'2014:" << flightDate.tm_mon << ":"
      << flightDate.tm_mday << "\', "
      << "\'09:00:00\', \'21:00:00\', " // we are very punctual
      << "\'" << coachLeft << "\', "
      << "\'" << firstClassLeft << "\', "
      << "\'" << origin << "\', "
      << "\'" << destination << "\') ";
  
  // add customers
  // initalize traveler table
  char * traveler;
  sprintf(traveler,"INSERT INTO `Traveler` (`orderNum`, `tfirstname`, ");
  sprintf(traveler,"%s`tmiddlename`, `tlastname`, `email`, ", traveler);
  sprintf(traveler,"%s`address`, `city`, `state`, `zip`, ", traveler);
  sprintf(traveler,"%s`zip`, `phone`, `passport`, `dob`, ", traveler);
  sprintf(traveler,"%s`type`, `addBags`) VALUES\n", traveler);

  out << "INSERT INTO `Reservation` (`orderNum`, `cid`, `dfid`, `rfid`, `qty`, "
      << "`cardFirstName`, `cardMiddleName`, `cardLastName`, `cardType`, "
      << "`cardNum`, `cardMonth`, `cardYear`, `address`, `city`, `state`, "
      << "`zip`, `orderDate`) VALUES";

  // firstclass first as allways  
  int sold = FIRST_CLASS_SEATS - firstClassLeft;
  
  while (sold > 0)
  {
    Customer cust;
    char * orderNum = generateOrderNumber();
    int seats = rand() % 2 + 1;
    if (seats > sold) // just in case we sell to many seats
      sold = seats;
    bool validCust;
    int cid;
    // no one is registered first class customers will not be registered
    cust = generateCustomer(cust);

    // print out reservation info
    out << "(\'" << orderNum << "\', \'\', "
        << "\'" << flightID << "\', \'\', " // not doing return flight in here
        << "\'" << sold << "\', "
        << "\'" << cust.firstName << "\', "
        << "\'" << cust.middleName << "\', "
        << "\'" << cust.lastName << "\', "
        << "\'Visa\', \'" << cardNumber() << "\', "
        << "\'" << rand() % 12 + 1 << "\', "
        << "\'" << rand() % 6 + 2014 << "\', "
        << "\'" << cust.address << "\' "
        << "\'" << cust.city << "\', "
        << "\'" << cust.state << "\', " 
        << "\'" << cust.zip << "\', "
        << "\'2013:12:01\'),\n";
    // print out traveler info
    sprintf(traveler, "%s(\'%s\', ", traveler, orderNum);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.firstName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.middleName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.lastName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.email);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.address);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.city);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.state);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.zip);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.phone);
    sprintf(traveler, "%s\'%s\', ", traveler, passport());
    sprintf(traveler, "%s\'%s:", traveler, cust.DOB.tm_year + 1900);
    sprintf(traveler, "%s%s:", traveler, cust.DOB.tm_mon);
    sprintf(traveler, "%s%s\', ", traveler, cust.DOB.tm_mday);
    sprintf(traveler, "%s\'First Class\', ", traveler);
    sprintf(traveler, "%s\'%s\'),\n", traveler, rand() % 4 + 1);

  }
  
  sold = COACH_SEATS - coachLeft;
  while (sold > 0)
  {
    Customer cust;
    char * orderNum = generateOrderNumber();
    int seats = rand() % 2 + 1;
    if (seats > sold) // just in case we sell to many seats
      sold = seats;
    cust = generateCustomer(cust);
    // print out reservation info
    out << "(\'" << orderNum << "\', \'\', "
        << "\'" << flightID << "\', \'\', " // not doing return flight in here
        << "\'" << sold << "\', "
        << "\'" << cust.firstName << "\', "
        << "\'" << cust.middleName << "\', "
        << "\'" << cust.lastName << "\', "
        << "\'Visa\', \'" << cardNumber() << "\', "
        << "\'" << rand() % 12 + 1 << "\', "
        << "\'" << rand() % 6 + 2014 << "\', "
        << "\'" << cust.address << "\' "
        << "\'" << cust.city << "\', "
        << "\'" << cust.state << "\', " 
        << "\'" << cust.zip << "\', "
        << "\'2013:12:01\'),\n";
    // print out traveler info
    sprintf(traveler, "%s(\'%s\', ", traveler, orderNum);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.firstName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.middleName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.lastName);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.email);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.address);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.city);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.state);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.zip);
    sprintf(traveler, "%s\'%s\', ", traveler, cust.phone);
    sprintf(traveler, "%s\'%s\', ", traveler, passport());
    sprintf(traveler, "%s\'%s:", traveler, cust.DOB.tm_year + 1900);
    sprintf(traveler, "%s%s:", traveler, cust.DOB.tm_mon);
    sprintf(traveler, "%s%s\', ", traveler, cust.DOB.tm_mday);
    sprintf(traveler, "%s\'Coach\', ", traveler);
    sprintf(traveler, "%s\'%s\'),\n", traveler, rand() % 4 + 1);
  }
  out << "\b\b;\n\n" << traveler << ";\n\n" ;
}

tm dayToDate(int day)
{
  tm returnTime;

  int month_len[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
  returnTime.tm_mday = day;

  for (returnTime.tm_mon = 0; returnTime.tm_mon < 12; returnTime.tm_mon++) 
  {
    int mlen = month_len[returnTime.tm_mon];
    if (returnTime.tm_mday <= mlen)
        break;
    returnTime.tm_mday -= mlen;
  }
  return returnTime;
}

char * generateOrderNumber()
{
  char * returnString;
  char list[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  for(int i = 0; i < 255; i++)
  {
    sprintf(returnString, "%s%c", returnString, list[rand()%62]);
  }
  return returnString;
}

char * passport()
{
  char * returnString;
  char list[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  for(int i = 0; i < 16; i++)
  {
    sprintf(returnString, "%s%c", returnString, list[rand()%62]);
  }
  return returnString;
}

char * cardNumber()
{
  char * returnString;
  sprintf(returnString,"4");
  for (int i = 0; i < 15; i++)
    sprintf(returnString,"%s%i",returnString,rand() % 10);
  return returnString;
}
