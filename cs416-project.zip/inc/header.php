<!DOCTYPE html>
<head>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Cache-Control" content="no-cache" />
<meta name="keywords" content="airplane, airline, internet, tickets" />
<meta name="description" content="<?php echo $description; ?>" />

<title><?php echo $title; ?></title>
<link rel="icon" type="image/jpeg" href="http://iamun.com/cs416/project/img/logo_sm.jpg" />
<script type="text/javascript" language="Javascript" src="http://iamun.com/cs416/project/js/all.js"></script>
<link rel="stylesheet" type="text/css" href="http://iamun.com/cs416/project/css/style1.css"> 
</head>
<body>
<form action="<?php echo $action; ?>" method="POST" onsubmit="<?php echo $onsubmit; ?>" name="mainform" id="mainform" style="width:100%; height:100%">
<table align="center" style="width:100%; height:100%"><tr><td style="width:100%; height:100%; vertical-align:middle">
<table id="main_table" align="center">
	<tr style="height:75px">
		<td style="width:50%; text-align:left">
			<img class="img" src="http://iamun.com/cs416/project/img/logo.jpg" title="Helping you get from point A to point B...faster" alt="The Internet Airline" onclick="javascript: window.location = 'http://iamun.com/cs416/project';" />
		</td>
		<td style="width:50%; text-align:center">
			<span>
				<?php
				
				$welcome = '<a href="login.php">Login</a> | <a href="register.php">Register</a>';
				$cookie = $_COOKIE['cid'];  // get the customer id cookie (if it exists)
				
				if ($cookie != '')
				{
					// Get the customer name from the database
					$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
					$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
					
					$query = "SELECT `cfirstname` FROM `Customer` WHERE `cid`=:1";
					
					$stmt = $db->prepare($query);
					$stmt->execute(array(':1' => $cookie));
					$result = $stmt->fetch();
					
					$cfirstname = $result[0];
					$welcome = "Welcome <b>".$cfirstname."!</b>";
				}
				
				echo $welcome;
				
				?>
			</span>
		</td>
	</tr>
	<tr style="height:60px">
		<td colspan="2" style="border-bottom: 2px #000000 groove">
			<table align="center">
				<tr>
					<td class="topbutton"><a href="http://iamun.com/cs416/project">Start Over</a></td>
					<td class="topbutton"><a href="http://iamun.com/cs416/project/deals">Great Deals</a></td>
					<td class="topbutton"><a href="http://iamun.com/cs416/project/help">Help / Information</a></td>
					<td class="topbutton"><a href="http://iamun.com/cs416/project/contact">Contact Us</a></td>
				</tr>
			</table>
		</td>
	</tr>
