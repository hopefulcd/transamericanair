	<tr class="bg1">
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:350px" cellpadding="5">
				<tr><td class="searchlimit" colspan="100">Login:</td></tr>
				<tr>
					<td class="select" style="border:0px">Email:</td>
					<td><input class="inText" type="text" name="email" /></td>
				</tr>
				<tr>
					<td class="select" style="border:0px">Password:</td>
					<td><input class="inText" type="password" name="password" /></td>
				</tr>
				<tr>
					<td class="select" style="border:0px" colspan="100">
						Don't Have An Account? &nbsp; <a href="http://iamun.com/cs416/project/register.cgi" onclick="return change('login')">Create An Account</a>
					</td>
				</tr>
				<tr><td class="important" style="font-style:normal" colspan="100"><?php echo $error; ?></td></tr>
				<tr>
					<td class="searchlimit" colspan="100">
						<input type="submit" title="Continue To Enter Your Billing Information" value="Login" />
						<input type="hidden" name="dflight" value="<?php echo $in_dflight; ?>" />
						<input type="hidden" name="rflight" value="<?php echo $in_rflight; ?>" />
						<input type="hidden" name="quantity" value="<?php echo $in_quantity; ?>" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
