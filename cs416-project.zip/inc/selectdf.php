	<tr>
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%; height:100%" cellpadding="5">
				<tr style="height:25px;"><td class="searchlimit" colspan="100"><span>Select A Departure Flight:</span></td></tr>
				<tr class="selectlimit" style="height:25px;">
					<td></td>
					<td>Flight ID</td>
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Origin</td>
					<td>Destination</td>
					<td>Class</td>
					<td>Seats Available</td>
					<td>Price</td>
				</tr>
				
				<?php for ($i=0; $i<count($htmlFlightList); $i++) {print $htmlFlightList[$i];} ?>
				
				<tr style="height:25px;">
					<td class="searchlimit" colspan="100">
						<?php echo $continue; ?>
						<input type="hidden" name="rdate" value="<?php echo $in_rdate; ?>" />
						<input type="hidden" name="origCity" value="<?php echo $origCity; ?>" />
						<input type="hidden" name="origState" value="<?php echo $origState; ?>" />
						<input type="hidden" name="destCity" value="<?php echo $destCity; ?>" />
						<input type="hidden" name="destState" value="<?php echo $destState; ?>" />
						<input type="hidden" id="selected" name="selected" value="" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
