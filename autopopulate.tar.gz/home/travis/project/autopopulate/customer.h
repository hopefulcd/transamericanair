// the customer portion of the autopopulation
#include "namelist.h" // file created to contain all the names to be used  
	    	      //        for random customer creation
#include "cities.h"   //used to pick a random city for the customer
#include <ctime>  //used for time structure
#include <cstdlib> //used for rand()
#include <stdio.h> //used for sprintf()
#include <string.h> //used for concatenating strings to form the customers email
		    //and address
#include <iostream> // for testing purposes
using namespace std;


#define MAX_CUSTOMER 8400 // max customers is 8400
#define TOT_FLIGHTS 18900

struct Customer {
  int cid;
  char firstName[30];
  char middleName[30];
  char lastName[30];
  char email[90];
  char address[60];
  char city[30];
  char state[3];
  int  zip;
  long phone;
  char password[30];
  tm DOB; // time structure provided by ctime
};


Customer generateCustomer(Customer cust)
{
//  struct Customer cust;
  int MAX_CUST_AGE = 70; //maximum age of customers with an account 
  int MIN_CUST_AGE = 21; //minimum age of customers with an account


  cust.cid = 0; //Initialization
  //CID will be a random 9 digit number
  for(int i=100000000; i >= 1; i=i/10)
  { //random number between 0 and 9, shift to i'th place
    cust.cid += rand() % 10 * i;
  }


  strcpy(cust.firstName,First[rand() % FNAME_LENGTH]);

  //Middle name is a random First name 
  strcpy(cust.middleName,First[rand() % FNAME_LENGTH]);
  strcpy(cust.lastName,Last[rand() % LNAME_LENGTH]);
	
  //firstname.lastname@gmail.com
  strcpy(cust.email, cust.firstName);
  strcat(cust.email, ".");
  strcat(cust.email, cust.lastName);
  strcat(cust.email, "@gmail.com");


  // CUSTOMER ADDRESS 
  //begin by generating a random 4 digit house number
  int houseNumber = 0; 
  for(int i=1000; i >= 1; i = i/10)
  {

    if(i == 1000) //first number won't be zero
      houseNumber += (rand() % 9 + 1) * i;
    else
      houseNumber += rand() % 10 * i;
  }
  //add house number to customer address
  sprintf(cust.address, "%u", houseNumber);
  //itoa(houseNumber, cust.address, 10);
  strcat(cust.address, " ");  

  
  //A random third of all streets will have numeric names
  if(rand() % 3 == 1)
  {
    int *streetName;

    //keep track of the last 2 numbers for determining the suffix of
    //the street name (1st, 2nd, 3rd, 13th, 23rd,...)
    //we need to keep track of the second to last number because
    //the 'teens' all have a 'th' suffix
    int num1 = rand() % 10;
    int num2 = rand() % 10;
    int num3 = rand() % 10;

    //if first number is 0, ignore it. Else, multiply it by 100 so it is
    // the first number. This allows for 2-digit street names
    if(num1 == 0) //then the second number can't be 0
      num2 = rand() % 9 + 1;
    else
      streetName += num1 * 100; //streetName = x00

    streetName += num2 * 10; //streetName = xy0
    streetName += num3;      //streetname = xyz

    //add street name to customer address
    strcat(cust.address, (char*)(streetName));
    
    //add different suffixes to street name dependant on its last 2 numbers
    if(num3 == 1 && num2 != 1)
      strcat(cust.address, "st");
    else if(num3 == 2 && num2 != 1)
      strcat(cust.address, "nd");
    else if(num3 == 3 && num2 != 1)
      strcat(cust.address, "rd");
    else //all other suffixes are 'th'
      strcat(cust.address, "th");
    //all roads with number names will be streets, because this seems 
    //to be the most common
    strcat(cust.address, " St."); 
  }


  //The remaining 2/3 of street names will be found by picking a random 
  //road name / suffix combo from nameslist.h
  else
  {  

    strcat(cust.address, roadName[rand() % RNAME_LENGTH]); 
    //random road name 
   
    strcat(cust.address, " ");
    strcat(cust.address, roadSuffix[rand() % RSUFFIX_LENGTH]); 
    //random road type 
  }


  int cityint = rand() % TOT_CITIES; //used for determining city/state
  sprintf(cust.city,"%s", cityList[cityint].name);
  sprintf(cust.state,"%s",cityList[cityint].state);
  
  cust.zip = 0; //initialization
  //zip is forced to be a 5-digit number
  for(int i=10000; i >= 1; i=i/10)
  {
    cust.zip += rand() % 10 * i;
  }//zip code
 
  //customer phone number is a random 10 digit number
  cust.phone = rand() % 8 + 2;
  for(int i=0; i < 9; i++)
  {
    cust.phone *=10;
    cust.phone += rand() % 10;
  }//phone number
 

  //Months since January
  cust.DOB.tm_mon = rand() % 12; 
  //random int  between 0 and 11, Jan = 0 , Dec = 11

  //picks random number between span of customer ages,0 corresponds to 
  //the max age, max-min+1 corresponds to the minimum age
  cust.DOB.tm_year = rand() % (MAX_CUST_AGE - MIN_CUST_AGE + 1); 

  //move number in span of age to corresponding number of years since 1900
  cust.DOB.tm_year += (2013 - MAX_CUST_AGE - 1900);
  
  //now that we have the year, determine whether it is a leap year or not
  // jetcityorange.com/leap-year/
  bool leapYear = false;
  if((cust.DOB.tm_year + 1900) % 400 == 0 ||
    ((cust.DOB.tm_year + 1900) % 4 == 0 &&
      (cust.DOB.tm_year + 1900) % 100 != 0)) leapYear = true;


  //30 days hath September, April, June, and November (8, 3, 5, 10)
  if(cust.DOB.tm_mon == 3 || 
     cust.DOB.tm_mon == 5 || 
     cust.DOB.tm_mon == 8 || 
     cust.DOB.tm_mon == 10)  cust.DOB.tm_mday = rand() % 30;

  //February, No leap year
  else if(cust.DOB.tm_mon == 1 && !leapYear) 
    cust.DOB.tm_mday = rand() % 28;

  //February, leap year
  else if(cust.DOB.tm_mon == 1 && leapYear)
    cust.DOB.tm_mday = rand() % 29;
  
  //all other cases have 31 days
  else
    cust.DOB.tm_mday = rand() % 31;

  //customer password will be a concatenation of their first name,
  //last name, and the year they were born
  strcpy(cust.password, cust.firstName);
  strcat(cust.password, cust.lastName);
  sprintf(cust.password,"%u", cust.DOB.tm_year + 1900);

  return cust;	     
}//generateCustomer()
