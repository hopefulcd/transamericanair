<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Select A Return Flight";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/selecttq.php";
$onsubmit = "";
$in_dflight = $_POST["radio"];  // the incoming RADIO value
$in_rdate = $_POST["rdate"];  // the incoming RETURNING DATE value
$origCity  = $_POST["origCity"];  // the incoming ORIGIN CITY value
$origState = $_POST["origState"];  // the incoming ORIGIN STATE value
$destCity  = $_POST["destCity"];  // the incoming DESTINATION CITY value
$destState = $_POST["destState"];  // the incoming DESTINATION STATE value
$code = "";  // variable used to hold some HTML code

/* Print the HTML code for the page header */
require($INC_DIR."header.php");


/* Create the Select Return Flight List */

$htmlFlightList = array();

// Read from the database
$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

/* Get the flight information */
$query = "SELECT G.`fid`, G.`fnumber`, G.`fdate`, G.`ftime`, G.`orig`, G.`dest`, G.`class`, G.`available`, G.`price` FROM `Flight` F, `Flight` G WHERE F.`fid`=:dflight AND F.`orig`=G.`dest` AND F.`dest`=G.`orig` AND G.`fdate`=:rdate ORDER BY `ftime`";
$stmt = $db->prepare($query);
$stmt->execute(array(':dflight' => $in_dflight, ':rdate' => $in_rdate));

/* Bind variables by column name */
$stmt->bindColumn('fid', $fid);
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('orig', $orig);
$stmt->bindColumn('dest', $dest);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('available', $available);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	$code = '
	<tr class="select" id="row_'.$fid.'" onmouseover="bgcolorover('.$fid.',\'s\')" onmouseout="bgcolorout('.$fid.',\'s\')" onclick="select('.$fid.',\'s\')">
		<td><input type="radio" name="radio" id="radio_'.$fid.'" value="'.$fid.'" /></td>
		<td>'.$fid.'</td>
		<td>'.$fnumber.'</td>
		<td>'.$fdate.'</td>
		<td>'.$ftime.'</td>
		<td>'.$origCity.', '.$origState.'</td>
		<td>'.$destCity.', '.$destState.'</td>
		<td>'.$class.'</td>
		<td>'.$available.'</td>
		<td>$'.$price.'</td>
	</tr>';
	
	array_push($htmlFlightList, $code);
}

if (count($htmlFlightList) == 0)
{
	$code = '<tr class="select" style="cursor:auto;"><td colspan="100">Sorry, No Return Fights Are Available.</td></tr>';
	array_push($htmlFlightList, $code);
	$continue = "";
}


/* Print the HTML code for the page body */
require($INC_DIR."selectrf.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");


?>
