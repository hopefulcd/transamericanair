// cities struct and then names

#define TOT_CITIES 14

typedef struct city {
  const char name[30];
  const char state[3];
} city;

city cityList[] = { {"New York", "NY"},
                    {"Los Angeles", "CA"},
                    {"Chicago", "IL"},
                    {"Houston", "TX"},
                    {"Phoenix", "AZ"},
                    {"Detroit", "MI"},
                    {"Indianapolis", "IN"},
                    {"Memphis", "TN"},
                    {"Boston", "MA"},
                    {"Juneau", "AK"},
                    {"Sacramento", "CA"},
                    {"Denver", "CO"},
                    {"Atlanta", "GA"},
                    {"Honolulu", "HI"},
                    {"Miami", "FL"},
                    {"Las Vegas", "NV"},
                    {"Louisville", "KY"},
                    {"Portland", "OR"}
                  };
