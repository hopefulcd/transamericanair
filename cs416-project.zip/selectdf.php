<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Select A Destination Flight";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/selectrf.php";
$onsubmit = "return isvalid('sdf')";
$continue = '<input type="submit" title="Continue To Select Your Return Flight" value="Continue" />';
$in_orig  = $_POST["from"];  // the incoming FROM value
$in_dest  = $_POST["to"];  // the incoming TO value
$in_ddate = $_POST["ddate"];  // the incoming DESTINATION DATE value
$in_rdate = $_POST["rdate"];  // the incoming RETURNING DATE value
$code = "";  // variable used to hold some HTML code

/* Print the HTML code for the page header */
require($INC_DIR."header.php");


/* Create the Select Destination Flight List */

$htmlFlightList = array();

// Read from the database
$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

/* Get the origin city information */
$query = "SELECT `title`, `state` FROM `City` WHERE `cityid`=:1";
$stmt = $db->prepare($query);
$stmt->execute(array(':1' => $in_orig));
$result = $stmt->fetch();

$origCity = $result[0];
$origState = $result[1];

/* Get the destination city information */
$query = "SELECT `title`, `state` FROM `City` WHERE `cityid`=:dest";
$stmt = $db->prepare($query);
$stmt->execute(array(':dest' => $in_dest));
$result = $stmt->fetch();

$destCity = $result[0];
$destState = $result[1];

/* Get the flight information */
$query = "SELECT `fid`, `fnumber`, `fdate`, `ftime`, `orig`, `dest`, `class`, `available`, `price` FROM `Flight` WHERE `fdate`=:date AND `orig`=:orig AND `dest`=:dest ORDER BY `ftime`";
$stmt = $db->prepare($query);
$stmt->execute(array(':date' => $in_ddate, ':orig' => $in_orig, ':dest' => $in_dest));

/* Bind variables by column name */
$stmt->bindColumn('fid', $fid);
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('orig', $orig);
$stmt->bindColumn('dest', $dest);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('available', $available);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	$code = '
	<tr class="select" id="row_'.$fid.'" onmouseover="bgcolorover('.$fid.',\'s\')" onmouseout="bgcolorout('.$fid.',\'s\')" onclick="select('.$fid.',\'s\')">
		<td><input type="radio" name="radio" id="radio_'.$fid.'" value="'.$fid.'" /></td>
		<td>'.$fid.'</td>
		<td>'.$fnumber.'</td>
		<td>'.$fdate.'</td>
		<td>'.$ftime.'</td>
		<td>'.$origCity.', '.$origState.'</td>
		<td>'.$destCity.', '.$destState.'</td>
		<td>'.$class.'</td>
		<td>'.$available.'</td>
		<td>$'.$price.'</td>
	</tr>';
	
	array_push($htmlFlightList, $code);
}

if (count($htmlFlightList) == 0)
{
	$code = '<tr class="select" style="cursor:auto;"><td colspan="100">Sorry, No Departure Fights Are Available.</td></tr>';
	array_push($htmlFlightList, $code);
	$continue = "";
}


/* Print the HTML code for the page body */
require($INC_DIR."selectdf.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");

?>