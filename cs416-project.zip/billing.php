<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Enter Your Billing Information";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/confirm.php";
$onsubmit = "return isvalid('b')";
$cdata = $_COOKIE["cdata"];  // the cdata cookie value
$cid = $_COOKIE["cid"];  // the cid cookie value

/* Get some variables from the cdata cookie */
list($in_dflight, $in_rflight, $in_quantity) = explode('/', $cdata);

/* Redirect if not from the correct page */
if ( ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/register.php") || ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/login.php") )
{; /* do nothing */}
else
{
	/* Redirect the browser */
	header("Location: http://iamun.com/cs416/project/");
}

/* Print the HTML code for the page header */
require($INC_DIR."header.php");


/* Create the HTML CARD MONTH list */
$htmlCardMonthList = array('<option value="NA" selected="selected"></option>');

for ($i=1; $i<=12; $i++)
{
	$monthName = date("F", mktime(0, 0, 0, $i, 22, 2013));
	array_push($htmlCardMonthList, '<option value="'.$i.'">'.$monthName.'</option>');
}


/* Create the HTML CARD YEAR list */
$htmlCardYearList = array('<option value="NA" selected="selected"></option>');

for ($i=0; $i<10; $i++)
{
	$year = intval(date("Y", mktime(0, 0, 0, 8, 22, 2013+$i)));
	array_push($htmlCardYearList, '<option value="'.$year.'">'.$year.'</option>');
}


/* Print the HTML code for the page body */
require($INC_DIR."billing.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");


?>
