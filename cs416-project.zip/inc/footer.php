	<tr>
		<td colspan="100" style="width:100%; height:50px">
			<table style="width:100%; height:50px">
				<tr>
					<td class="footer">Copyright 2013 &copy The Internet Airline Inc</td>
				</tr>
			</table>
		</td>
	</tr>
</table>
</td></tr></table>
</form>
</body>
</html>
