INSERT INTO `Customer` (`cfirstname`, `cmiddlename`, `clastname`, `email`, `address`, `city`, `state`, `zip`, `phone`, `passport`, `dob`, `password`) VALUES 
('Robert', 'Frodo', 'Cook', 'Robert.Cook@gmail.com', '6936 Dixie Blvd.', 'Chicago', 'IL', '18792', '4237592289', '1986', '1986:3:16'),
('Nathan', 'Nathan', 'Potter', 'Nathan.Potter@gmail.com', '3610 Jefferson Blvd.', 'Phoenix', 'AZ', '61554', '9656937452', '1957', '1957:9:26'),
('Kimball', 'Harold', 'Hunt', 'Kimball.Hunt@gmail.com', '9920 Dixie Rd.', 'Boston', 'MA', '66495', '4487172722', '1944', '1944:8:20'),
('Steve', 'Bud', 'Clooney', 'Steve.Clooney@gmail.com', '4597 Anchor Blvd.', 'Detroit', 'MI', '65639', '2812939088', '1983', '1983:11:22'),
('Ichabod', 'Dean', 'Robbin', 'Ichabod.Robbin@gmail.com', '2030 Ohio Rd.', 'Sacramento', 'CA', '76317', '7962178574', '1951', '1951:1:23'),
('Jesse', 'Ned', 'Twain', 'Jesse.Twain@gmail.com', '8338 Anchor Rd.', 'Chicago', 'IL', '88977', '6430309254', '1948', '1948:6:10')