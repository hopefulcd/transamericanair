<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Login";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "";
$onsubmit = "";
$in_rflight = $_POST["rflight"];  // the incoming RETURN FLIGHT value
$in_dflight = $_POST["dflight"];  // the incoming DEPARTURE FLIGHT value
$in_quantity = $_POST["quantity"];  // the incoming QUANTITY value
$in_email = $_POST["email"];  // the incoming EMAIL value
$in_password = $_POST["password"];  // the incoming PASSWORD value
$error = "";  // variable used to hold some HTML code
$loggedIn = 0;  // boolean variable used to determine if the customer is logged in or not

/* If submitted, then check the login information */
if ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/login.php")
{
	$in_email = str_replace(' ', '', $in_email);
	$in_email = strtolower($in_email);
	$loggedIn = 2;
	
	// Read from the database
	$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	
	/* Get the Customer's Information */
	$query = "SELECT `cid`, `email`, `password` FROM `Customer` WHERE lower(`email`)=:email";
	$stmt = $db->prepare($query);
	$stmt->execute(array(':email' => $in_email));
	
	/* Bind variables by column name */
	$stmt->bindColumn('cid', $cid);
	$stmt->bindColumn('email', $email);
	$stmt->bindColumn('password', $password);
	
	while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
	{
		if ($password == $in_password) {$loggedIn = 1;}
		
		if ($loggedIn == 1)
		{
			/* Create the Customer ID cookie */
			setcookie('cid',$cid,time()+(2*3600)); // cookie expires after 2 hours
			
			/* Create the Customer DATA cookie */
			$cdata = $in_dflight.'/'.$in_rflight.'/'.$in_quantity;
			setcookie('cdata',$cdata,time()+(.25*3600)); // cookie expires after 30 minutes
			
			/* Redirect the browser */
			header("Location: http://iamun.com/cs416/project/billing.php");
		}
	}
}


/* Print the HTML code for the page header */
require($INC_DIR."header.php");


if ($loggedIn == 2) {$error = "Incorrect Login Information.<br>Please Login Again.";}
else {$error = "";}


/* Print the HTML code for the page body */
require($INC_DIR."login.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");


?>
