<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Great Ticket Prices, Easy to Use, Award Winning Support";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/selectdf.php";
$onsubmit = "return isvalid('home')";

/* Print the HTML code for the page header */
require($INC_DIR."header.php");


/* Create the HTML City List */

// Read from the database
$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

$query = "SELECT `cityid`, `title`, `state` FROM `City` ORDER BY `title`, `state`";

$stmt = $db->prepare($query);
$stmt->execute();

/* Bind variables by column name */
$stmt->bindColumn('cityid', $cityid);
$stmt->bindColumn('title', $title);
$stmt->bindColumn('state', $state);

$htmlCityList = array('<option value="NA" selected="selected"></option>');

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	array_push($htmlCityList, '<option value="'.$cityid.'">'.$title.', '.$state.'</option>');
}

/* Create the HTML Date List */

$htmlDateList = array();
$month = intval(date('n'));
$dayofmonth = intval(date('j'));
$year = intval(date('Y'));
$next_year = $year+1;

$numdays = array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);

$count = 0;
for ($i=0; $i<12; $i++)
{
	for ($j=1; $j<=$numdays[$i]; $j++)
	{
		$k = $i+1;
		if ( ($k == $month) && ($j == $dayofmonth) ) {array_push($htmlDateList, '<option value="'.$year.'-'.$k.'-'.$j.'" selected="selected">'.$k.'/'.$j.'/'.$year.'</option>'); $count=1;}
		elseif ( (($k != $month) || ($j != $dayofmonth)) && ($count == 1) ) {array_push($htmlDateList, '<option value="'.$year.'-'.$k.'-'.$j.'">'.$k.'/'.$j.'/'.$year.'</option>');}
		else {array_push($htmlDateList, '<option value="'.$next_year.'-'.$k.'-'.$j.'">'.$k.'/'.$j.'/'.$next_year.'</option>');}
	}
}

/* Print the HTML code for the page body */
require($INC_DIR."home.php");

/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");

?>
