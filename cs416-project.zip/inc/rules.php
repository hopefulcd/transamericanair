	<tr class="bg1">
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%; height:80%" cellpadding="5">
				<tr><td class="searchlimit" style="height:25px;" colspan="100"><span>The Internet Airlines System Rules:</span></td></tr>
				<tr class="search" style="text-align:center"><td>By using this site, you, as the user hereby agree to follow all of the system rules. If you're found disobeying any of these rules, it's likely that you'll be banned from future use of this site and any programs that this site is involved in. That being said, these rules shouldn't be hard at all to abide by. The system rules are as follows:</td></tr>
				<tr class="selectlimit">
					<td>
						<ul class="important" style="text-align:left">
							<li>You will not spam any email addresses found within this site!</li>
							<li>You agree to not hold The Internet Airlines Inc. responsible for any problems caused on your computer from use of this site.</li>
							<li>You will not use any threatening, vulgar, mean, degrading, or perverse language in any of your comments on this site.</li>
							<li>You will kindly report any suggestions for improvement or questions that you may have to our staff.</li>
							<li>You will not use any internet robots to steal information from this site.</li>
							<li>You will not break into any of The Internet Airline Inc. databases or misrepresent this site in any way.</li>
						</ul>
					</td>
				</tr>
				<tr><td class="searchlimit" style="height:25px;" colspan="100"><span></span></td></tr>
			</table>
		</td>
	</tr>
