	<tr class="bg1">
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:450px" cellpadding="5">
				<tr><td class="searchlimit" colspan="100">Enter Your Billing Information:</td></tr>
				<tr>
					<td>
						<span><span class="required">*</span> Card Numer: &nbsp;</span>
						<input type="text" name="cardnum" id="cardnum" title="Enter Your Credit Card Number" maxlength="16" onkeypress="return ismax(event, 'b', 10)" />
					</td>
				</tr>
				<tr>
					<td>
						<span><span class="required">*</span> Card Month: &nbsp;</span>
						<select name="cardmonth" id="cardmonth" title="Select Your Credit Card Month">
							<?php for ($i=0; $i<count($htmlCardMonthList); $i++) {print $htmlCardMonthList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<span><span class="required">*</span> Card Year: &nbsp;</span>
						<select name="cardyear" id="cardyear" title="Select Your Credit Card Year">
							<?php for ($i=0; $i<count($htmlCardYearList); $i++) {print $htmlCardYearList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="searchlimit" colspan="100">
						<input type="submit" title="Continue To The Confirm Your Reservation Page" value="Continue" />
						<input type="hidden" name="dflight" value="<?php echo $in_dflight; ?>" />
						<input type="hidden" name="rflight" value="<?php echo $in_rflight; ?>" />
						<input type="hidden" name="quantity" value="<?php echo $in_quantity; ?>" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
