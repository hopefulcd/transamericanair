	<tr>
		<td class="searchlimit" colspan="2" style="text-align:center">
			Would You Like A Return Flight? &nbsp; &nbsp; 
			Yes<input type="radio" name="question" id="questionY" value="Y" />
			No<input type="radio" name="question" id="questionN" value="N" onclick="unselect()" />
		</td>
	</tr>
	<tr>
		<td class="important" colspan="2" style="text-align:center">DISCOUNT - <u>40% off ALL Round Trip Flights!</u> - Limited Time Offer!</td>
	</tr>
	<tr>
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%; height:100%;" cellpadding="5">
				<tr style="height:25px;"><td class="searchlimit" colspan="100"><span>Select A Return Flight:</span></td></tr>
				<tr class="selectlimit" style="height:25px;">
					<td></td>
					<td>Flight ID</td>
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Origin</td>
					<td>Destination</td>
					<td>Class</td>
					<td>Seats Available</td>
					<td>Price</td>
				</tr>
				
				<?php for ($i=0; $i<count($htmlFlightList); $i++) {print $htmlFlightList[$i];} ?>
				
				<tr style="height:25px;">
					<td class="searchlimit" colspan="100">
						<input type="submit" title="Continue To Select Your Ticket Quantity" value="Continue" />
						<input type="hidden" name="dflight" value="<?php echo $in_dflight; ?>" />
						<input type="hidden" id="selected" name="selected" value="" />
					</td>
				</tr>
			</table>
		</td>
	</tr>
