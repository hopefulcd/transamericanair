<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Flight Reservation";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "";
$onsubmit = "";
$in_rflight = $_POST["rflight"];  // the incoming RETURN FLIGHT value
$in_dflight = $_POST["dflight"];  // the incoming DEPARTURE FLIGHT value
$in_quantity = $_POST["quantity"];  // the incoming QUANTITY value
$in_cardnum = $_POST["cardnum"];  // the incoming CARD NUMBER value
$in_cardmonth = $_POST["cardmonth"];  // the incoming CARD MONTH value
$in_cardyear = $_POST["cardyear"];  // the incoming CARD YEAR value
$dflight = "";  // variable used to hold some HTML code for the DEPARTURE FLIGHT
$rflight = "";  // variable used to hold some HTML code for the RETURN FLIGHT
$orderSummary = "";  // variable used to hold some HTML code for the ORDER SUMMARY
$dprice = 0;  // variable that holds the DESTINATION TICKET PRICE
$rprice = 0;  // variable that holds the RETURN TICKET PRICE
$discount = "--";  // variable that holds the DISCOUNT text
$total = 0;  // variable that holds the ORDER TOTAL PRICE
$cid = $_COOKIE["cid"];  // the cid cookie value
$ordernum = 0; // variable used to hold the order number
$result = "";  // variable used to hold the result
$resultMessage = "";  // variable used to hold the result message
$orderDate = "";  // variable used to hold the order date of the reservation
$orderNum = 0; // variable used to hold the order number of the reservation
$htmlOrderNum = "";  // variable used to hold the HTML for the order number of the reservation
$davailable = 0; // variable used to hold the available number of tickets for the departure flight
$ravailable = 0; // variable used to hold the available number of tickets for the return flight



/* Redirect if not from the correct page */
if ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/confirm.php")
{; /* do nothing */}
else
{
	/* Redirect the browser */
	header("Location: http://iamun.com/cs416/project/");
}


/* Print the HTML code for the page header */
require($INC_DIR."header.php");


// Read from the database
$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

/* Get the Result of the Order */

if (isset($in_rflight)) {$query = "SELECT `available` FROM `Flight` WHERE `fid` IN (:dflight, :rflight)";}
else {$query = "SELECT `available` FROM `Flight` WHERE `fid` IN (:dflight)";}

$stmt = $db->prepare($query);
$stmt->execute(array(':dflight' => $in_dflight, ':rflight' => $in_rflight));

/* Bind variables by column name */
$stmt->bindColumn('available', $available);

$result  = '<span class="sucess">Successful Reservation!</span>';
$valid = 1;

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	if ( ($available - $in_quantity) < 0 ) {$result = '<span class="fail">Unsucessful Reservation!</span>'; $valid = 0;}
}


/* RESULT was Unsuccessful */
if ($valid != 1)
{
	$htmlOrderNum = "";
	$resultMessage = "Sorry, one of your selected flights is unavailable for the amount of tickets that you're trying to reserve. If you'd still like to purchase tickets, please select a lower quantity.";
	
	/* Print the HTML code for the page body */
	require($INC_DIR."submit.php");

	/* Print the HTML code for the page footer */
	require($INC_DIR."footer.php");
	
	exit;
}

/* RESULT was Successful */

$year = date("Y");
$month = date("n");
$day = date("d");
$orderDate = $year."-".$month."-".$day;

/* Insert the Flight Reservation into the Database */
$query = "INSERT INTO `Reservation` (`cid`, `dfid`, `rfid`, `qty`, `cardnum`, `cardmonth`, `cardyear`, `order_date`) VALUES (:cid, :dflight, :rflight, :quantity, :cardnum, :cardmonth, :cardyear, :orderDate)";
$stmt = $db->prepare($query);
$stmt->execute(array(':cid' => $cid, ':dflight' => $in_dflight, ':rflight' => $in_rflight, ':quantity' => $in_quantity, ':cardnum' => $in_cardnum, ':cardmonth' => $in_cardmonth, ':cardyear' => $in_cardyear, ':orderDate' => $orderDate));

// read from the database
$query = "SELECT `ordernum` FROM `Reservation` WHERE `cid`=:cid ORDER BY `ordernum` DESC";
$stmt = $db->prepare($query);
$stmt->execute(array(':cid' => $cid));

/* Bind variables by column name */
$stmt->bindColumn('ordernum', $oNum);

$count = 0;
while ( ($row = $stmt->fetch(PDO::FETCH_BOUND)) && ($count == 0) )
{
	$orderNum = $oNum;
	$htmlOrderNum = '<tr><td class="submit">Thank you for your reservation! 
	<br><br>Your order number is: '.$orderNum.'
	<br><br>You will receive a confirmation email shortly with your order details.
	<br><br>Please keep your order number for your personal records.</td></tr>';
	$count++;
}

/* Send The Confirmation Email */

/* Get the Departure Flight Information */
$query = "SELECT `fnumber`, `fdate`, `ftime`, `class`, `price` FROM `Flight` WHERE `fid`=:dflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':dflight' => $in_dflight));

/* Bind variables by column name */
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	$dflight = '
	<tr class="select display" colspan="100">
		<td>'.$fnumber.'</td>
		<td>'.$fdate.'</td>
		<td>'.$ftime.'</td>
		<td>'.$class.'</td>
		<td colspan="3">$'.$price.'</td>
	</tr>';
	
	$dprice = $price;
}


/* Get the Return Flight Information */
$rflight = '<tr class="select display"><td colspan="100">No Return Flight Selected</td></tr>';

$query = "SELECT `fnumber`, `fdate`, `ftime`, `class`, `price` FROM `Flight` WHERE `fid`=:rflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':rflight' => $in_rflight));

/* Bind variables by column name */
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	if (isset($in_rflight))
	{
		$rflight = '
		<tr class="select display" colspan="100">
			<td>'.$fnumber.'</td>
			<td>'.$fdate.'</td>
			<td>'.$ftime.'</td>
			<td>'.$class.'</td>
			<td colspan="3">$'.$price.'</td>
		</tr>';
		
		$rprice = $price;
	}
}


/* Get the Order Summary Information */

if (isset($in_rflight))
{
	$discount = "40% off";
	$total = (($in_quantity * $dprice) + ($in_quantity * $rprice)) * (0.6); 
	$total = sprintf("%.2f", $total);
}
else
{
	$discount = "--"; 
	$total = $in_quantity * $dprice; 
	$total = sprintf("%.2f", $total);
}

// read from the database
$query = "SELECT `cfirstname`, `clastname`, `email`, `address` FROM `Customer` WHERE `cid`=:cid";
$stmt = $db->prepare($query);
$stmt->execute(array(':cid' => $cid));

/* Bind variables by column name */
$stmt->bindColumn('cfirstname', $cfirstname);
$stmt->bindColumn('clastname', $clastname);
$stmt->bindColumn('email', $email);
$stmt->bindColumn('address', $address);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
		$orderSummary = '
		<tr class="select display">
			<td>'.$cfirstname.'</td>
			<td>'.$clastname.'</td>
			<td>'.$email.'</td>
			<td>'.$address.'</td>
			<td>'.$in_quantity.'</td>
			<td>'.$discount.'</td>
			<td>$'.$total.'</td>
		</tr>';
}


// setup the email variables
$to = $email;
$from = 'sales@theinternetairline.com';
$subject = 'Your Flight Reservation Order Summary | The Internet Airline';

// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$headers .= 'To: <'.$email.'>' . "\r\n";
$headers .= 'From: The Internet Airline <'.$from.'>' . "\r\n";


// create the HTML email message
$message = '
	<html>
	<head>
	<title>'.$subject.'</title>
	<style>
		p {
			font-weight:700;
			font-size:20px;
		}
		
		p font {
			font-weight:800;
			text-decoration:underline;
			color:#008800;
			margin-bottom:20px;
		}
		
		table {
			border:2px solid #000000;
			font:bold 15px Arial;
			width:500px;
			text-align:left;
		}
		
		table tr {
			border:2px solid #000000;
		}
		
		.select { 
			text-align: center; 
			background-color:#030085; 
			border:1px #E0E0E0 solid; 
			font-size: 12px; 
			font-family: Arial, Verdana, sans-serif; 
			color: #FFFFFF; 
			cursor: auto;
		}
		
		.selectlimit { 
			text-align: center; 
			background-color:#FFFFFF; 
			font-size: 12px; 
			font-family: Arial, Verdana, sans-serif; 
			font-weight: bold; 
			color: #030085;
		}
		
		.searchlimit { 
			text-align: center; 
			background-color:#FFFFFF; 
			font-size: 16px; 
			font-family: Arial, Verdana, sans-serif; 
			font-weight: bold; 
			color: #030085;
		}
		
		.footer { 
			text-align: center; 
			background-color:#E0E0E0; 
			font-size: 12px; 
			font-family: Arial, Verdana, sans-serif; 
			color: #030085;
		}
		
		#wrapper {
			width:100%;
			height:100%;
		}
		
		#content {
			text-align:center;
		}
	</style>
	
	</head>
	<body>
	<div id="wrapper">
		<div align="center" id="content">
			<h2>Thank you for your reservation!</h2>
			<p>Here\'s your Flight Reservation information. Your Order Number is: <font>'.$orderNum.'</font>:</p>
			<br><br>
			<table align="center" style="width:100%" cellpadding="5">
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Departure Flight:</span></td></tr>
				<tr class="selectlimit" colspan="100" style="height:25px;">
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Class</td>
					<td colspan="3">Price</td>
				</tr>
				'.$dflight.'
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Return Flight:</span></td></tr>
				<tr class="selectlimit" colspan="100" style="height:25px;">
					<td>Flight Number</td>
					<td>Flight Date</td>
					<td>Flight Time</td>
					<td>Class</td>
					<td colspan="3">Price</td>
				</tr>
				'.$rflight.'
				<tr><td class="searchlimit" colspan="100" style="height:25px;"><span>Your Flight Reservation Summary:</span></td></tr>
				<tr class="selectlimit" style="height:25px;">
					<td>First Name</td>
					<td>Last Name</td>
					<td>Email</td>
					<td>Shipping Address</td>
					<td>Ticket Quantity</td>
					<td>Discount</td>
					<td>Total</td>
				</tr>
				'.$orderSummary.'
			</table>
			<br><br>
			<span>If you have any questions, please contact us at sales@theinternetairline.com</span>
			<br><br>
			<div class="footer">Copyright 2013 &copy The Internet Airline Inc</div>
			
		</div>
	</div>
	</body>
	</html>
	';


// Send the email
mail($to, $subject, $message, $headers);


/* Update the Flight Availability Lists */

// Get the departure flight availability number
$query = "SELECT `available` FROM `Flight` WHERE `fid`=:dflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':dflight' => $in_dflight));

/* Bind variables by column name */
$stmt->bindColumn('available', $av);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
		$davailable = intval($av) - $in_quantity;
}

// Update the departure flight availability
$query = "UPDATE `Flight` SET `available`=:davailable WHERE `fid`=:dflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':davailable' => $davailable, ':dflight' => $in_dflight));


// Get the return flight availability number
$query = "SELECT `available` FROM `Flight` WHERE `fid`=:rflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':rflight' => $in_rflight));

/* Bind variables by column name */
$stmt->bindColumn('available', $av);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
		$ravailable = intval($av) - $in_quantity;
}

// Update the return flight availability
$query = "UPDATE `Flight` SET `available`=:ravailable WHERE `fid`=:rflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':ravailable' => $ravailable, ':rflight' => $in_rflight));


/* Print the HTML code for the page body */
require($INC_DIR."submit.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");


?>