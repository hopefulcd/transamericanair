	<tr class="bg1">
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%" cellpadding="5">
				<tr><td class="searchlimit" colspan="100"><span>Contact The Internet Airline</span></td></tr>
				<tr class="search"><td>Email: contact-us@theinternetairlines.com</td></tr>
				<tr class="search"><td>We welcome your input and suggestions!</td></tr>
				<tr class="search"><td>For Questions and Comments: support@theinternetairline.com</td></tr>
				<tr class="search"><td>For Sales: sales@theinternetairline.com</td></tr>
				<tr class="selectlimit"><td></td></tr>
				<tr class="search"><td>Address:</td></tr>
				<tr class="search"><td>The Internet Airline Inc.</td></tr>
				<tr class="search"><td>134 W Chester Ave.</td></tr>
				<tr class="search"><td>San Francisco, CA 94118</td></tr>
				<tr>
					<td class="searchlimit" colspan="100"></td>
				</tr>
			</table>
		</td>
	</tr>
