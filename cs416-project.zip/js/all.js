/*
Name: Charles Dyke
Date: 11/04/2010
Description: This file holds all (or mostly all) of the javascript functions that are used for cs442.iamun.com.
*/

function bgcolorover(num, ch)
{
	var row  = "row_" + num;
	var sel   = document.getElementById("selected");

	if (ch == 's')
	{
		if ((sel.value) != row) {document.getElementById(row).style.backgroundColor = "#302BFF";}
	}
}

function bgcolorout(num, ch)
{
	var row  = "row_" + num;
	var sel   = document.getElementById("selected");

	if (ch == 's')
	{
		if ((sel.value) != row) {document.getElementById(row).style.backgroundColor = "#030085";}
	}
}

function select(num, ch)
{
	var row   = "row_" + num;
	var radio = "radio_" + num;
	var sel   = document.getElementById("selected");
	var qY = document.getElementById("questionY");
	
	if (ch == 's')
	{
		if (sel.value) {document.getElementById(sel.value).style.backgroundColor = "#030085";}
		document.getElementById(row).style.backgroundColor = "#302BFF";
		document.getElementById(radio).checked = "checked";
		sel.value = row;
		if (qY) {qY.checked = true;}
	}
}

function unselect()
{
	var qN	    = document.getElementById("questionN");
	var sel     = document.getElementById("selected");
	var mysplit = sel.value.split("_");
	var radio   = document.getElementById("radio_" + mysplit[1]);
	
	if (sel.value) {document.getElementById(sel.value).style.backgroundColor = "#030085";}
	radio.checked = false;
	sel.value = "";
}

function ismax(evt, ch, maxnum)
{
	var charCode = (evt.which) ? evt.which : event.keyCode;
	if (charCode > 31 && (charCode < 48 || charCode > 57)) {return false;}
	var num  = String.fromCharCode(charCode);
	
	if (ch == "stq")
	{
		var q = document.getElementById("quantity");
		var total = (q.value != "") ? ((10*q.value) + (1*num)) : num;
		if (total > maxnum) {alert("Sorry, you can only purchase a maximum of 10 sets of tickets at a time."); return false;}
		if (total == 0) {alert("Sorry, you must purchase a minimum of 1 ticket."); return false;}
	}
	
	return true;
}

function isvalid(ch)
{
	if (ch == 'stq')
	{
		var q = document.getElementById("quantity");
		if (q.value == "") {alert("Error: You Haven't Entered A Ticket Quantity."); return false;}
	}
	
	if (ch == 'b')
	{
		var cardnum   = document.getElementById("cardnum");
		var cardmonth = document.getElementById("cardmonth");
		var cardyear  = document.getElementById("cardyear");
		var error1 = (document.forms.mainform.cardnum.value.length < 16) ? "Error: Invalid Credit Card Number.\n" : "";
		var error2 = (cardmonth.options[cardmonth.selectedIndex].value == "NA") ? "Error: You Haven't Selected Your Credit Card Month.\n" : "";
		var error3 = (cardyear.options[cardyear.selectedIndex].value == "NA") ? "Error: You Haven't Selected Your Credit Card Year.\n" : "";
		
		if ( (error1 != "") || (error2 != "") || (error3 != "") ) {alert(error1 + error2 + error3); return false;}
	}
	
	if (ch == 'home')
	{
		var from   = document.getElementById("from");
		var to     = document.getElementById("to");
		var error1 = (from.options[from.selectedIndex].value == "NA") ? "Error: You Haven't Selected An Origin City.\n" : "";
		var error2 = (to.options[to.selectedIndex].value == "NA") ? "Error: You Haven't Selected A Destination City.\n" : "";
		
		if ( (error1 != "") || (error2 != "") ) {alert(error1 + error2); return false;}
	}
	
	if ( (ch == 'deals') || (ch == 'sdf') )
	{
		var sel = document.getElementById("selected");
		if (sel.value == "") {alert("Error: You Haven't Selected A Flight."); return false;}
	}
	
	return true;
}

function change(ch)
{
	if (ch == 'login')
	{
		document.mainform.action = "http://iamun.com/cs416/project/register.cgi";
		document.mainform.submit();
	}
	
	return false;
}

