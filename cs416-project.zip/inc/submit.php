	<tr>
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%; height:90%" cellpadding="5">
				<tr style="height:25px"><td class="submitlimit" colspan="100"><?php echo $result; ?></td></tr>
				
				<?php echo $htmlOrderNum; ?>
				
				<tr>
					<td class="select" style="cursor:auto; border:0px; font-size:14px"><?php echo $resultMessage; ?></td>
				</tr>
				<tr style="height:25px"><td></td></tr>
			</table>
		</td>
	</tr>
