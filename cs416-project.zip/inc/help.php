	<tr class="bg1">
		<td colspan="2" style="text-align:center">
			<table class="search" align="center" style="width:80%; height:50%;" cellpadding="5">
				<tr><td class="searchlimit" style="height:25px;" colspan="100"><span>Welcome to The Internet Airline!</span></td></tr>
				<tr class="search" style="text-align:center"><td>This site is dedicated to providing you with the easiest, fastest, and most up-to-date airline tickets. Our Flights database is constantly being updated with the newest and best flights so that you can find the best ticket prices for your trip!</td></tr>
				<tr class="search"><td>You can view the site guidelines here: <a href="http://iamun.com/cs416/project/rules.php">View Rules</a></td></tr>
				<tr class="search"><td>If you need to get in contact with us, go here: <a href="http://iamun.com/cs416/project/contact/">Display Contact Information</a></td></tr>
				<tr><td class="searchlimit" colspan="100"><span></span></td></tr>
			</table>
		</td>
	</tr>
