<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Confirm Your Flight Reservation";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/submit.php";
$onsubmit = "";
$in_rflight = $_POST["rflight"];  // the incoming RETURN FLIGHT value
$in_dflight = $_POST["dflight"];  // the incoming DEPARTURE FLIGHT value
$in_quantity = $_POST["quantity"];  // the incoming QUANTITY value
$in_cardnum = $_POST["cardnum"];  // the incoming CARD NUMBER value
$in_cardmonth = $_POST["cardmonth"];  // the incoming CARD MONTH value
$in_cardyear = $_POST["cardyear"];  // the incoming CARD YEAR value
$dflight = "";  // variable used to hold some HTML code for the DEPARTURE FLIGHT
$rflight = "";  // variable used to hold some HTML code for the RETURN FLIGHT
$orderSummary = "";  // variable used to hold some HTML code for the ORDER SUMMARY
$dprice = 0;  // variable that holds the DESTINATION TICKET PRICE
$rprice = 0;  // variable that holds the RETURN TICKET PRICE
$discount = "--";  // variable that holds the DISCOUNT text
$total = 0;  // variable that holds the ORDER TOTAL PRICE
$cid = $_COOKIE["cid"];  // the cid cookie value

/* Redirect if not from the correct page */
if ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/billing.php")
{; /* do nothing */}
else
{
	/* Redirect the browser */
	header("Location: http://iamun.com/cs416/project/");
}


/* Print the HTML code for the page header */
require($INC_DIR."header.php");


// Read from the database
$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

/* Get the Departure Flight Information */
$query = "SELECT `fnumber`, `fdate`, `ftime`, `class`, `price` FROM `Flight` WHERE `fid`=:dflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':dflight' => $in_dflight));

/* Bind variables by column name */
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	$dflight = '
	<tr class="select display" colspan="100">
		<td>'.$fnumber.'</td>
		<td>'.$fdate.'</td>
		<td>'.$ftime.'</td>
		<td>'.$class.'</td>
		<td colspan="3">$'.$price.'</td>
	</tr>';
	
	$dprice = $price;
}

/* Get the Return Flight Information */
$rflight = '<tr class="select display"><td colspan="100">No Return Flight Selected</td></tr>';

$query = "SELECT `fnumber`, `fdate`, `ftime`, `class`, `price` FROM `Flight` WHERE `fid`=:rflight";
$stmt = $db->prepare($query);
$stmt->execute(array(':rflight' => $in_rflight));

/* Bind variables by column name */
$stmt->bindColumn('fnumber', $fnumber);
$stmt->bindColumn('fdate', $fdate);
$stmt->bindColumn('ftime', $ftime);
$stmt->bindColumn('class', $class);
$stmt->bindColumn('price', $price);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
	if (isset($in_rflight))
	{
		$rflight = '
		<tr class="select display" colspan="100">
			<td>'.$fnumber.'</td>
			<td>'.$fdate.'</td>
			<td>'.$ftime.'</td>
			<td>'.$class.'</td>
			<td colspan="3">$'.$price.'</td>
		</tr>';
		
		$rprice = $price;
	}
}


/* Get the Order Summary Information */

if (isset($in_rflight))
{
	$discount = "40% off";
	$total = (($in_quantity * $dprice) + ($in_quantity * $rprice)) * (0.6); 
	$total = sprintf("%.2f", $total);
}
else
{
	$discount = "--"; 
	$total = $in_quantity * $dprice; 
	$total = sprintf("%.2f", $total);
}

// read from the database
$query = "SELECT `cfirstname`, `clastname`, `email`, `address` FROM `Customer` WHERE `cid`=:cid";
$stmt = $db->prepare($query);
$stmt->execute(array(':cid' => $cid));

/* Bind variables by column name */
$stmt->bindColumn('cfirstname', $cfirstname);
$stmt->bindColumn('clastname', $clastname);
$stmt->bindColumn('email', $email);
$stmt->bindColumn('address', $address);

while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
{
		$orderSummary = '
		<tr class="select display">
			<td>'.$cfirstname.'</td>
			<td>'.$clastname.'</td>
			<td>'.$email.'</td>
			<td>'.$address.'</td>
			<td>'.$in_quantity.'</td>
			<td>'.$discount.'</td>
			<td>$'.$total.'</td>
		</tr>';
}


/* Print the HTML code for the page body */
require($INC_DIR."confirm.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");


?>