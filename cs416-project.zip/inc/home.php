	<tr>
		<td colspan="2" style="text-align:center"><img src="img/welcome.jpg" title="Helping you get from point A to point B...faster" alt="Welcome to The Internet Airline!"/></td>
	</tr>
	<tr>
		<td style="text-align:center"><img src="img/airplane.jpg" title="Want to get away?" alt="If you can't see this image, reload the page."/></td>
		<td style="text-align:center">
			<table class="search" align="center" style="width:80%" cellpadding="5">
				<tr><td class="searchlimit"><span>Search Flights:</span></td></tr>
				<tr>
					<td>
						<span>From: &nbsp;</span>
						<select name="from" id="from" title="Select Your Departure City">
							<?php for ($i=0; $i<count($htmlCityList); $i++) {print $htmlCityList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<span>To: &nbsp;</span>
						<select name="to" id="to" title="Select Your Arrival City">
							<?php for ($i=0; $i<count($htmlCityList); $i++) {print $htmlCityList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<span>Departing Date: &nbsp;</span>
						<select name="ddate" id="ddate" title="Select Your Departing Date">
							<?php for ($i=0; $i<count($htmlDateList); $i++) {print $htmlDateList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<span>Returning Date: &nbsp;</span>
						<select name="rdate" id="rdate" title="Select Your Returning Date">
							<?php for ($i=0; $i<count($htmlDateList); $i++) {print $htmlDateList[$i];} ?>
						</select>
					</td>
				</tr>
				<tr>
					<td class="searchlimit"><input type="submit" title="Search All Available Flights" value="Search" /></td>
				</tr>
			</table>
		</td>
	</tr>
