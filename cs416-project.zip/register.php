<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Register A New Account";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "http://iamun.com/cs416/project/register.php";
$onsubmit = "";
$in_rflight = $_POST["rflight"];  // the incoming RETURN FLIGHT value
$in_dflight = $_POST["dflight"];  // the incoming DEPARTURE FLIGHT value
$in_quantity = $_POST["quantity"];  // the incoming QUANTITY value
$in_cfirstname = $_POST["cfirstname"];  // the incoming CUSTOMER FIRST NAME value
$in_clastname = $_POST["clastname"];  // the incoming CUSTOMER LAST NAME value
$in_address = $_POST["address"];  // the incoming ADDRESS value
$in_city = $_POST["city"];  // the incoming CITY value
$in_state = $_POST["state"];  // the incoming STATE value
$in_zip = $_POST["zip"];  // the incoming ZIP value
$in_phone = $_POST["phone"];  // the incoming PHONE value
$in_email = $_POST["email"];  // the incoming EMAIL value
$in_password = $_POST["password"];  // the incoming PASSWORD value
$in_repassword = $_POST["repassword"];  // the incoming REPASSWORD value
$count = NULL;  // variable used to determine the correct area to branch to next
$cdata = "";  // variable used to hold some cookie data

/* If submitted, then check the registration information */
if ($_SERVER['HTTP_REFERER'] == "http://iamun.com/cs416/project/register.php")
{
	$in_email = str_replace(' ', '', $in_email);
	$in_email = strtolower($in_email);
	
	// Read from the database
	$db = new PDO('mysql:host=localhost;dbname=woodmarc_cs442;charset=utf8', 'woodmarc_cs442', 'cs442');
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	
	/* Get the Customer's Information */
	$query = "SELECT `email` FROM `Customer` WHERE lower(`email`)=:email";
	$stmt = $db->prepare($query);
	$stmt->execute(array(':email' => $in_email));
	
	/* Bind variables by column name */
	$stmt->bindColumn('email', $email);
	
	$count = 1;
	while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
	{
		if ($email != "") {$count = 0;}
	}
	
	if ($count == 1)
	{
		if ( ($in_email != "") && ($in_cfirstname != "") && ($in_clastname != "") && ($in_address != "") && ($in_password == $in_repassword) && ($in_password != "") )
		{
			$query = "INSERT INTO `Customer` (`cfirstname`, `clastname`, `email`, `address`, `city`, `state`, `zip`, `phone`, `password`) VALUES (:cfirstname, :clastname, :email, :address, :city, :state, :zip, :phone, :password)";
			$stmt = $db->prepare($query);
			$stmt->execute(array(':cfirstname' => $in_cfirstname, ':clastname' => $in_clastname, ':email' => $in_email, ':address' => $in_address, ':city' => $in_city, ':state' => $in_state, ':zip' => $in_zip, ':phone' => $in_phone, ':password' => $in_password));
			$count = 3;
			
			$query = "SELECT `cid` FROM `Customer` WHERE lower(`email`)=:email";
			$stmt = $db->prepare($query);
			$stmt->execute(array(':email' => $in_email));
			
			/* Bind variables by column name */
			$stmt->bindColumn('cid', $cid);
			
			while ($row = $stmt->fetch(PDO::FETCH_BOUND)) 
			{
				/* Create the Customer ID cookie */
				setcookie('cid',$cid,time()+(2*3600)); // cookie expires after 2 hours
				
				/* Create the Customer DATA cookie */
				$cdata = $in_dflight.'/'.$in_rflight.'/'.$in_quantity;
				setcookie('cdata',$cdata,time()+(.25*3600)); // cookie expires after 30 minutes
			}
		}
		
		if ( ($in_dflight != "") && ($count == 3) )
		{
			/* Redirect the browser to billing.php */
			header("Location: http://iamun.com/cs416/project/billing.php");
			exit;
		}
		if ($count == 3)
		{
			/* Redirect the browser back to index.php */
			header("Location: http://iamun.com/cs416/project/index.php");
			exit;
		}
	}
	
	$count = 2;
}


/* Print the HTML code for the page header */
require($INC_DIR."header.php");



/* Check the submitted registration information */

// Customer First Name
if ( ($in_cfirstname == "") && ($count == 2) )
{
	$errorcFirstName = "ERROR: You Must Enter A First Name.<br>";
	$cfirstname = "";
}
else
{
	$errorcFirstName = "";
	$cfirstname = $in_cfirstname;
}

// Customer Last Name
if ( ($in_clastname == "") && ($count == 2) )
{
	$errorcLastName = "ERROR: You Must Enter A Last Name.<br>";
	$clastname = "";
}
else
{
	$errorcLastName = "";
	$clastname = $in_clastname;
}

// Address
if ( ($in_address == "") && ($count == 2) )
{
	$errorAddress = "ERROR: You Must Enter An Address.<br>";
	$address = "";
}
else 
{
	$errorAddress = "";
	$address = $in_address;
}

// City
if ( ($in_city == "") && ($count == 2) )
{
	$errorCity = "ERROR: You Must Enter A City.<br>";
	$city = "";
}
else 
{
	$errorCity = "";
	$city = $in_city;
}

// State
if ( ($in_state == "") && ($count == 2) )
{
	$errorState = "ERROR: You Must Select A State.<br>";
	$state = "";
}
else 
{
	$errorState = "";
	$state = $in_state;
}

// Zip
if ( ($in_zip == "") && ($count == 2) )
{
	$errorZip = "ERROR: You Must Enter A Zip Code.<br>";
	$zip = "";
}
else 
{
	$errorZip = "";
	$zip = $in_zip;
}

// Phone
if ( ($in_phone == "") && ($count == 2) )
{
	$errorPhone = "ERROR: You Must Enter A Phone Number.<br>";
	$phone = "";
}
else 
{
	$errorPhone = "";
	$phone = $in_phone;
}

// Email
if ( (($email != "") || ($in_email == "")) && ($count == 2) )
{
	$errorEmail = "ERROR: The Email Entered Is Invalid.<br>";
	$email = "";
}
else 
{
	$errorEmail = "";
	$email = $in_email;
}

// Password
if ( (($in_password != $in_repassword) || ($in_password == "")) && ($count == 2) )
{
	$errorPassword = "ERROR: The Passwords Entered Are Invalid.<br>";
	$password = "";
	$repassword = "";
}
else
{
	$errorPassword = "";
	$password = $in_password;
	$repassword = $in_repassword;
}


/* Print the HTML code for the page body */
require($INC_DIR."register.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");









/*
###############################################################################################
#	Print the HTML code for the page
###############################################################################################

$page = HTML::Template->new(filename => 'tmpl/register.tmpl');

if ( ($in_cname eq "") && ($count == 2) )
{
	$page->param(ERROR_CNAME => "ERROR: You Must Enter A Name.<br>\n");
	$page->param(CNAME => qq(value=""));
}
else {$page->param(ERROR_CNAME => ""); $page->param(CNAME => qq(value="$in_cname"));}

if ( ($in_address eq "") && ($count == 2) )
{
	$page->param(ERROR_ADDRESS => "ERROR: You Must Enter An Address.<br>\n");
	$page->param(ADDRESS => qq(value=""));
}
else {$page->param(ERROR_ADDRESS => ""); $page->param(ADDRESS => qq(value="$in_address"));}

if ( (($email ne "") || ($in_email eq "")) && ($count == 2) )
{
	$page->param(ERROR_EMAIL => "ERROR: The Email Entered Is Invalid.<br>\n");
	$page->param(EMAIL => qq(value=""));
}
else {$page->param(ERROR_EMAIL => ""); $page->param(EMAIL => qq(value="$in_email"));}

if ( (($in_password ne $in_repassword) || ($in_password eq "")) && ($count == 2) )
{
	$page->param(ERROR_PASSWORD => "ERROR: The Passwords Entered Are Invalid.<br>\n");
	$page->param(PASSWORD => qq(value=""));
	$page->param(REPASSWORD => qq(value=""));
}
else {$page->param(ERROR_PASSWORD => ""); $page->param(PASSWORD => qq(value="$in_password")); $page->param(REPASSWORD => qq(value="$in_repassword"));}

$page->param(DFLIGHT_FID => $in_dflight);
$page->param(RFLIGHT_FID => $in_rflight);
$page->param(QUANTITY => $in_quantity);

#####################################################
# Print the Page
#####################################################

print $page->output;

###############################################################################################
#	Print the HTML code for the page footer
###############################################################################################

$footer = HTML::Template->new(filename => 'tmpl/footer.tmpl');
print $footer->output;

*/


?>