<?php

/* Create the setup variables */
$INC_DIR = "/home/woodmarc/public_html/iamun.com/cs416/project/inc/";
$title = "The Internet Airline  | Contact Us";
$description = "Welcome to The Internet Airline! Your one stop source for reserving airline tickets.";
$action = "";
$onsubmit = "";

/* Print the HTML code for the page header */
require($INC_DIR."header.php");


/* Print the HTML code for the page body */
require($INC_DIR."contact.php");


/* Print the HTML code for the page footer */
require($INC_DIR."footer.php");

?>