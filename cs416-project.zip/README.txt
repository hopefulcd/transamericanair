/*
 Student Names: Charles Dyke, 
 Course: CS 416
 Project Description: This project is an online airline reservation system.
 File Description: This is the airline reservation system README file. This file shows the
 necessary steps in order to reserve tickets using the online reseservation system.
*/

/* Online Airline Ticket Reservation System */


// TO GET IT RUNNING

This program was written in ...

1. Go to http://iamun.com/cs416/project

2. a) Go to LOGIN 
      or 
   b) Select your flight information

a) If you select your flight information

NOTE: AS of 09/03/2013, only the following information works:
 
 Pheonix, AZ as the FROM City
 Columbus, OH as the TO City
 12/21/2013 for the departure date
 12/28/2013 for the return date
 
(More information will be added to the database shortly)

b) If you went to LOGIN
 ...
